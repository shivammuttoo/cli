# project
A command line program in JS to process the log file with cookies.
Nodejs has been used to build the program.
Test cases are written using Mocha test library.
In ./src folder all the source code can be found.
CSV file is stored in assets folder. 
Test cases can be found inside tests folder. 

# Step to setup the project
- install node from https://nodejs.org/en

To run the program run command below

```
npm run start
```

To run the test cases run command below

```
npm run test
```

