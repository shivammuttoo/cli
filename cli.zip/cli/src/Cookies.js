const {formatedDate} = require('./Utils')


/**
 * The `getCookies()` method returns cookies and their frequency
 * @param rows Rows fetched from CSV files.
 * @param formatedDate Formated date ex: 2019-01-20
 * @return object with cookies frequency ex: { cookie2: 1, cookie1: 2, cookie3: 1 }.
 */

exports.getCookies = async function(rows, formatedInputDate){
    const cookies = {}
    let header = true;

     for await (let line of rows){
        if(header){
            header = false;
            continue;
        }
        const [cookie, timestamp] = line.trim().split(',');
        const logDate = formatedDate(timestamp) 
        if(logDate === formatedInputDate){
            cookies[cookie] = (cookies[cookie] || 0) + 1;
        }
    }
    return cookies
}