/**
 * The `formatedDate(date)` method returns cookies and their frequency
 * @param date as string having fetched from CSV file.
 * @return Formated date ex: 2019-01-20.
 */

exports.formatedDate = function(date){
    return (new Date(date)).toISOString().split('T')[0]
}

/**
 * The `isValidDate(dateString)` function returns whether the date passed as parameter is valid or not
 * @param dateString date as a string 
 * @return `true` or `false`
 */

exports.isValidDate = function(dateString){
    const date = new Date(dateString);

    // Check if the parsed date is valid and matches the original string
    return date.toISOString().slice(0,10) === dateString;
}

/**
 * The `findMaxValueObject(cookieObject)` function returns whether the date passed as parameter is valid or not
 * @param cookieObject  frequency ex: { cookie2: 1, cookie1: 2, cookie3: 1 }
 * @return `array` array of objects with maximum values ex: [{key: 'cookie1', value:2 }]
 */

exports.findMaxValueObject = function(cookieObject) {
    let maxKey = null;
    let maxValue = -Infinity;

    // Find the maximum value in the object.
    for (const key in cookieObject) {
        if (cookieObject[key] > maxValue) {
            maxKey = key;
            maxValue = cookieObject[key];
        }
    }

    // Find all keys in the object with the maximum value
    const maxObjects = [];
    for (const key in cookieObject) {
        if (cookieObject[key] === maxValue) {
            maxObjects.push({ key, value: cookieObject[key] });
        }
    }

    return maxObjects;
}