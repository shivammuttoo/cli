const {isValidDate, findMaxValueObject} = require('../Utils');
var assert = require('assert');
describe('Utils',()=>{
    it('is valid date',()=>{
        let date = '2012-02-02';
        assert.equal(isValidDate(date), true)
    })

    it('is invalid date',()=>{
        let date = '2023-02-29';
        assert.equal(isValidDate(date), false)
    })

    it('Find maximum value object',()=>{
        const object =  {cookie2: 3, cookie1: 1, cookie3: 1 };
        assert.deepEqual(findMaxValueObject({cookie2: 3, cookie1: 1, cookie3: 1 }), [{key: 'cookie2', value:3 }])
    })
})