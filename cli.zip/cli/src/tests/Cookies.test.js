const {getCookies} = require('../Cookies')
var assert = require('assert');
describe('Cookies',()=>{
    it('Get frequency of cookies',async ()=>{
        let date = '2018-12-09';
        const mockData = [
        'cookie,timestamp',
        'cookie1,2018-12-09T10:00:00',
        'cookie2,2018-12-09T14:19:00+00:00',
        'cookie1,2018-12-09T14:19:00+00:00',
        'cookie3,2018-12-09T14:19:00+00:00',
    ];
       const data = await getCookies(mockData,date)
       
        assert.deepEqual( data,{ cookie2: 1, cookie1: 2, cookie3: 1 })
    })
    
    
})