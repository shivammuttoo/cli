const fs = require('fs');
const readline = require('readline');
const {getCookies} = require('./Cookies')
const {formatedDate, isValidDate, findMaxValueObject} = require('./Utils')
const args = process.argv.slice(2);
const fileArgumetnIndex = args.indexOf('-f');
const dateArgumentIndex = args.indexOf('-d');
const MISSING_PARAMS = 'File or date parameters missing.';
const INVALID_DATE = 'Invalid date, please check your date.';

exports.getRecentCookies = async function(){
    // Basic validations to check wheter the parameters and date are valid or not 
    if(fileArgumetnIndex == -1 || dateArgumentIndex == -1 || dateArgumentIndex!=fileArgumetnIndex+2){
        console.error(MISSING_PARAMS);
        return;
    }else if(!isValidDate(args[dateArgumentIndex+1])){
        console.error(INVALID_DATE);
        return;
    }

    const inputDate = args[dateArgumentIndex+1];
    const fileName = args[fileArgumetnIndex+1];
    const filePath = `./src/assets/${fileName}`

    const formatedInputDate = formatedDate(inputDate);
    const rows = readline.createInterface({
        input: fs.createReadStream(filePath),
        crlfDelay: Infinity
    });
    
    const cookies = await getCookies(rows, formatedInputDate);
    const recentCookies = findMaxValueObject(cookies);
    for(let recentCookie of recentCookies){
        console.log(recentCookie.key);
    }
}
exports.getRecentCookies();



